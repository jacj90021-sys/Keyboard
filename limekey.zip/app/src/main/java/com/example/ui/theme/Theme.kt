package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LimeDark,
    secondary = LimeDarkShadow,
    tertiary = KeyDark,
    background = PaperDark,
    surface = PaperDark,
    onPrimary = InkLight,
    onSecondary = InkLight,
    onBackground = InkDark,
    onSurface = InkDark
)

private val LightColorScheme = lightColorScheme(
    primary = LimeLight,
    secondary = LimeLightShadow,
    tertiary = SpecialKeyLight,
    background = PaperLight,
    surface = PaperLight,
    onPrimary = InkLight,
    onSecondary = InkLight,
    onBackground = InkLight,
    onSurface = InkLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
