package com.example.keyboard

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun PaperLimeKeyboardView(
    palette: KeyboardPalette,
    onCommitText: (String) -> Unit,
    onDelete: () -> Unit,
    onEnter: () -> Unit,
    onThemeChange: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var mode by rememberSaveable { mutableStateOf(KeyboardMode.QWERTY) }
    var shiftState by rememberSaveable { mutableStateOf(ShiftState.OFF) }
    var overlay by rememberSaveable { mutableStateOf(OverlayView.NONE) }
    var isToolbarExpanded by rememberSaveable { mutableStateOf(false) }
    var fnLongOverlay by rememberSaveable { mutableStateOf(false) }
    var lastShiftTapTime by remember { mutableLongStateOf(0L) }
    var clipboardList by remember {
        mutableStateOf(
            listOf(
                "Paper + Lime is an ergonomic keyboard.",
                "Quick brown fox jumps over the lazy dog.",
                "Hello World!"
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(palette.paper)
            .border(1.dp, palette.line)
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        // Floating Toolbar Overlay - placed at the top above suggestions
        AnimatedVisibility(
            visible = isToolbarExpanded,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            FloatingToolbar(
                palette = palette,
                onToolClick = { targetOverlay ->
                    overlay = if (overlay == targetOverlay) OverlayView.NONE else targetOverlay
                },
                onMoreClick = {
                    overlay = if (overlay == OverlayView.ALL_ACTIONS) OverlayView.NONE else OverlayView.ALL_ACTIONS
                }
            )
        }

        // Suggestions Bar
        SuggestionsBar(
            palette = palette,
            isExpanded = isToolbarExpanded,
            isFnMode = mode == KeyboardMode.FN || fnLongOverlay,
            onToggleExpand = {
                isToolbarExpanded = !isToolbarExpanded
                if (isToolbarExpanded) overlay = OverlayView.NONE
            },
            onSuggestionClick = { word ->
                if (mode == KeyboardMode.FN || fnLongOverlay) {
                    if (word == "Tab") onCommitText("\t")
                    else onCommitText("[$word]")
                } else {
                    onCommitText("$word ")
                }
            }
        )

        // OVERLAYS (All Actions, Emoji, Clipboard) OR KEYBOARD LAYOUTS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            when (overlay) {
                OverlayView.ALL_ACTIONS -> {
                    AllActionsGrid(
                        palette = palette,
                        onClose = { overlay = OverlayView.NONE },
                        onActionClick = { actionId ->
                            when (actionId) {
                                "language" -> {}
                                "undo" -> onDelete()
                                "redo" -> {}
                                "select_all" -> {}
                                "copy" -> {}
                                "paste" -> {
                                    if (clipboardList.isNotEmpty()) {
                                        onCommitText(clipboardList.first())
                                    }
                                }
                                "theme" -> onThemeChange?.invoke()
                                "numpad" -> {
                                    mode = KeyboardMode.NUMPAD
                                    overlay = OverlayView.NONE
                                }
                                "fn" -> {
                                    mode = KeyboardMode.FN
                                    overlay = OverlayView.NONE
                                }
                                "arrow_left" -> {}
                                "arrow_right" -> {}
                                "case" -> {}
                                "clear" -> {}
                                "voice" -> {}
                                "translate" -> {}
                            }
                        }
                    )
                }

                OverlayView.EMOJI -> {
                    EmojiPickerGrid(
                        palette = palette,
                        onClose = { overlay = OverlayView.NONE },
                        onEmojiClick = { emo ->
                            onCommitText(emo)
                        }
                    )
                }

                OverlayView.CLIPBOARD -> {
                    ClipboardListPanel(
                        palette = palette,
                        clips = clipboardList,
                        onClose = { overlay = OverlayView.NONE },
                        onClearAll = { clipboardList = emptyList() },
                        onClipClick = { clip ->
                            onCommitText(clip)
                        }
                    )
                }

                else -> {
                    // Standard Keyboard Layouts
                    when (mode) {
                        KeyboardMode.QWERTY -> {
                            QwertyLayoutView(
                                palette = palette,
                                shiftState = shiftState,
                                onKeyClick = { char ->
                                    onCommitText(char)
                                    if (shiftState == ShiftState.SHIFT) {
                                        shiftState = ShiftState.OFF
                                    }
                                },
                                onLongKeyClick = { num ->
                                    onCommitText(num)
                                },
                                onShiftClick = {
                                    val now = System.currentTimeMillis()
                                    if (now - lastShiftTapTime < 350) {
                                        shiftState = if (shiftState == ShiftState.CAPS_LOCK) ShiftState.OFF else ShiftState.CAPS_LOCK
                                    } else {
                                        shiftState = if (shiftState == ShiftState.OFF) ShiftState.SHIFT else ShiftState.OFF
                                    }
                                    lastShiftTapTime = now
                                },
                                onBackspaceClick = onDelete,
                                onSymbolsClick = { mode = KeyboardMode.SYMBOLS_1 },
                                onFnClick = { mode = KeyboardMode.FN },
                                onFnLongClick = { fnLongOverlay = !fnLongOverlay },
                                isFnLongActive = fnLongOverlay,
                                onSpaceClick = { onCommitText(" ") },
                                onEnterClick = onEnter,
                                onSpaceDrag = {}
                            )
                        }

                        KeyboardMode.SYMBOLS_1 -> {
                            SymbolsLayoutView(
                                palette = palette,
                                page = 1,
                                onKeyClick = { onCommitText(it) },
                                onSwitchPage = { mode = KeyboardMode.SYMBOLS_2 },
                                onLettersClick = { mode = KeyboardMode.QWERTY },
                                onNumpadClick = { mode = KeyboardMode.NUMPAD },
                                onBackspaceClick = onDelete,
                                onSpaceClick = { onCommitText(" ") },
                                onEnterClick = onEnter
                            )
                        }

                        KeyboardMode.SYMBOLS_2 -> {
                            SymbolsLayoutView(
                                palette = palette,
                                page = 2,
                                onKeyClick = { onCommitText(it) },
                                onSwitchPage = { mode = KeyboardMode.SYMBOLS_1 },
                                onLettersClick = { mode = KeyboardMode.QWERTY },
                                onNumpadClick = { mode = KeyboardMode.NUMPAD },
                                onBackspaceClick = onDelete,
                                onSpaceClick = { onCommitText(" ") },
                                onEnterClick = onEnter
                            )
                        }

                        KeyboardMode.NUMPAD -> {
                            NumpadLayoutView(
                                palette = palette,
                                onKeyClick = { onCommitText(it) },
                                onLettersClick = { mode = KeyboardMode.QWERTY },
                                onSymbolsClick = { mode = KeyboardMode.SYMBOLS_1 },
                                onEnterClick = onEnter
                            )
                        }

                        KeyboardMode.FN -> {
                            FnKeysLayoutView(
                                palette = palette,
                                onKeyClick = { f -> onCommitText("[$f]") },
                                onLettersClick = { mode = KeyboardMode.QWERTY },
                                onBackspaceClick = onDelete,
                                onSpaceClick = { onCommitText(" ") },
                                onEnterClick = onEnter
                            )
                        }
                    }
                }
            }
        }
    }
}
