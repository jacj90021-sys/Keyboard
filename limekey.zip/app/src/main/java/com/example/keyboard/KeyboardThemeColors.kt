package com.example.keyboard

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class ThemeChoice(val displayName: String) {
    PAPER("Paper + Lime"),
    DARK("Dark Ink"),
    MINIMAL("Minimal Slate"),
    FOREST("Forest Lime")
}

data class KeyboardPalette(
    val paper: Color,
    val paperSubtle: Color,
    val paperDeep: Color,
    val keyBg: Color,
    val ink: Color,
    val inkSecondary: Color,
    val muted: Color,
    val lime: Color,
    val limeShadow: Color,
    val line: Color,
    val keyShadow: Color,
    val specialKey: Color,
    val specialShadow: Color,
    val canvasBg: Color
)

fun getPalette(choice: ThemeChoice): KeyboardPalette {
    return when (choice) {
        ThemeChoice.PAPER -> KeyboardPalette(
            paper = PaperLight,
            paperSubtle = PaperLightSubtle,
            paperDeep = PaperLightDeep,
            keyBg = KeyLight,
            ink = InkLight,
            inkSecondary = InkLightSecondary,
            muted = MutedLight,
            lime = LimeLight,
            limeShadow = LimeLightShadow,
            line = LineLight,
            keyShadow = KeyShadowLight,
            specialKey = KeyLight,
            specialShadow = KeyShadowLight,
            canvasBg = CanvasBgLight
        )
        ThemeChoice.DARK -> KeyboardPalette(
            paper = PaperDark,
            paperSubtle = PaperDarkSubtle,
            paperDeep = PaperDarkDeep,
            keyBg = KeyDark,
            ink = InkDark,
            inkSecondary = InkDarkSecondary,
            muted = MutedDark,
            lime = LimeDark,
            limeShadow = LimeDarkShadow,
            line = LineDark,
            keyShadow = KeyShadowDark,
            specialKey = KeyDark,
            specialShadow = KeyShadowDark,
            canvasBg = CanvasBgDark
        )
        ThemeChoice.MINIMAL -> KeyboardPalette(
            paper = PaperMinimal,
            paperSubtle = Color(0xFFF1F5F9),
            paperDeep = Color(0xFFE2E8F0),
            keyBg = KeyMinimal,
            ink = InkMinimal,
            inkSecondary = Color(0xFF475569),
            muted = Color(0xFF94A3B8),
            lime = LimeMinimal,
            limeShadow = LimeMinimalShadow,
            line = LineMinimal,
            keyShadow = KeyShadowMinimal,
            specialKey = KeyMinimal,
            specialShadow = KeyShadowMinimal,
            canvasBg = Color(0xFFE2E8F0)
        )
        ThemeChoice.FOREST -> KeyboardPalette(
            paper = PaperForest,
            paperSubtle = Color(0xFFD6E2D3),
            paperDeep = Color(0xFFC3D4C0),
            keyBg = KeyForest,
            ink = InkForest,
            inkSecondary = Color(0xFF405940),
            muted = Color(0xFF748C74),
            lime = LimeForest,
            limeShadow = LimeForestShadow,
            line = LineForest,
            keyShadow = KeyShadowForest,
            specialKey = KeyForest,
            specialShadow = KeyShadowForest,
            canvasBg = Color(0xFFD0DED0)
        )
    }
}
