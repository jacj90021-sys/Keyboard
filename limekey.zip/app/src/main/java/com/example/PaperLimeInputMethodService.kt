package com.example

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.keyboard.PaperLimeKeyboardView
import com.example.keyboard.ThemeChoice
import com.example.keyboard.getPalette

class PaperLimeInputMethodService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@PaperLimeInputMethodService)
            setViewTreeViewModelStoreOwner(this@PaperLimeInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@PaperLimeInputMethodService)
            setContent {
                var themeChoice by remember { mutableStateOf(ThemeChoice.PAPER) }
                val palette = remember(themeChoice) { getPalette(themeChoice) }

                PaperLimeKeyboardView(
                    palette = palette,
                    onCommitText = { text ->
                        currentInputConnection?.commitText(text, 1)
                    },
                    onDelete = {
                        val ic = currentInputConnection
                        val selected = ic?.getSelectedText(0)
                        if (selected.isNullOrEmpty()) {
                            ic?.deleteSurroundingText(1, 0)
                        } else {
                            ic.commitText("", 1)
                        }
                    },
                    onEnter = {
                        currentInputConnection?.sendKeyEvent(
                            KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)
                        )
                        currentInputConnection?.sendKeyEvent(
                            KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)
                        )
                    },
                    onThemeChange = {
                        val all = ThemeChoice.entries
                        val next = (all.indexOf(themeChoice) + 1) % all.size
                        themeChoice = all[next]
                    }
                )
            }
        }
        return composeView
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
