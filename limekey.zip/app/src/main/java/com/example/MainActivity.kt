package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.keyboard.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var themeChoice by remember { mutableStateOf(ThemeChoice.PAPER) }
            val palette = remember(themeChoice) { getPalette(themeChoice) }

            MyApplicationTheme(
                darkTheme = themeChoice == ThemeChoice.DARK
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = palette.canvasBg
                ) {
                    KeyboardManagerScreen(
                        palette = palette,
                        themeChoice = themeChoice,
                        onThemeChange = {
                            val all = ThemeChoice.entries
                            val next = (all.indexOf(themeChoice) + 1) % all.size
                            themeChoice = all[next]
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun KeyboardManagerScreen(
    palette: KeyboardPalette,
    themeChoice: ThemeChoice,
    onThemeChange: () -> Unit
) {
    val context = LocalContext.current
    var testText by remember { mutableStateOf("") }

    val imm = remember {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    val isImeEnabled = remember {
        try {
            imm?.enabledInputMethodList?.any { it.packageName == context.packageName } == true
        } catch (_: Exception) {
            false
        }
    }

    val isImeSelected = remember {
        try {
            val currentMethod = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.DEFAULT_INPUT_METHOD
            ) ?: ""
            currentMethod.contains(context.packageName)
        } catch (_: Exception) {
            false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Paper + Lime Keyboard",
                        color = palette.ink,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Android Input Method Service (IME)",
                        color = palette.muted,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = onThemeChange,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.keyBg)
                        .border(1.dp, palette.line, RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Palette,
                        contentDescription = "Theme",
                        tint = palette.inkSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Status Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = palette.paper),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, palette.line, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Keyboard Activation",
                        color = palette.ink,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Step 1: Enable
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isImeEnabled) Icons.Default.CheckCircle else Icons.Default.Settings,
                                contentDescription = null,
                                tint = if (isImeEnabled) palette.limeShadow else palette.muted,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "1. Enable in System Settings",
                                color = palette.ink,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Button(
                            onClick = {
                                context.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isImeEnabled) palette.specialKey else palette.lime,
                                contentColor = palette.ink
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isImeEnabled) "Enabled" else "Enable", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Step 2: Select
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isImeSelected) Icons.Default.CheckCircle else Icons.Default.Keyboard,
                                contentDescription = null,
                                tint = if (isImeSelected) palette.limeShadow else palette.muted,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "2. Select as Active Keyboard",
                                color = palette.ink,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Button(
                            onClick = {
                                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                                imm.showInputMethodPicker()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isImeSelected) palette.specialKey else palette.lime,
                                contentColor = palette.ink
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isImeSelected) "Selected" else "Select", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Real Android Text Input Field to test typing
            OutlinedTextField(
                value = testText,
                onValueChange = { testText = it },
                label = { Text("Test Input Field") },
                placeholder = { Text("Tap to test typing with Paper + Lime...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.lime,
                    unfocusedBorderColor = palette.line,
                    focusedContainerColor = palette.keyBg,
                    unfocusedContainerColor = palette.keyBg
                )
            )
        }

        // LIVE KEYBOARD COMPONENT (Pure Keyboard without mock footers)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
        ) {
            PaperLimeKeyboardView(
                palette = palette,
                onCommitText = { char -> testText += char },
                onDelete = {
                    if (testText.isNotEmpty()) {
                        testText = testText.dropLast(1)
                    }
                },
                onEnter = { testText += "\n" },
                onThemeChange = onThemeChange
            )
        }
    }
}
